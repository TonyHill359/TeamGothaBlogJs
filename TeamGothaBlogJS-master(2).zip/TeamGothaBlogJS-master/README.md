# TeamGothaBlogJS
<br>
Team participants : <br>
1.Dimitar Srebrinov /DimitarS/ <br>
2.Antoan Gergov (TonyHill) <br>
3.Yovo Mitev /IovoMitev/ <br>
4.Radomir Kolev /radomir/ <br>
 <br>
<!--------kinvey credentials for this project :
email - d2maniaka@gmail.com
Password : GothaTeam  ------------->

